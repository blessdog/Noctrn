# Brutalist-Framework
A framework for the brutalist web design trend.
Version: 2.4
![BF Cover](http://www.brutalistframework.com/core/files/images/bf-social-tile.jpg)
## About
_Brutalist Framework_ is a responsive framework exclusively for the popular brutalist web design trend. It is intended to be a boilerplate for creating simple brutalist websites.

When dealing with brutalism, we like to think of it as being CRUDE:
* Cynically confrontational
* Roughly raw and rugged
* Uncomfortably ugly and unpolished
* Deliberately daring and damaging
* Extremely exasperated and embittered